<?php
$html	=	'<div style="width: 85%;   margin: 0 auto;  border-radius: 1px;  box-shadow: 0 0 1in -0.25in rgba(0, 0, 0, 0.5); padding: 40px;">
  <table width="100%" style=" color: #000; border-collapse: collapse; background: #fff; border: 0;">
    <tr>
      <td style="border-radius: 5px;  background-color: #fff;border: 2px solid #000;padding: 0.5em 0;"><table style="color: #000;  border-collapse: collapse;width: 100%;">
          <tr>
            <td style=" text-align: left;padding:0%;width:50%;"><b style="font-weight: bold;">
              <label style="display:block;font-weight:600;letter-spacing:2px;font-size:17px;padding:2px 10px;color:#000;font-family:Segoe UI,Calibri,Arial,sans-serif;text-transform:uppercase;">Jitendra Singh (8-B) Report Card</label>
              </b>
			</td>
			
			<td style=" text-align: right;padding:0%;width:50%;"><b style="font-weight: bold;">
              <label style="display:block;font-weight:600;letter-spacing:2px;font-size:14px;padding:2px 10px;color:#000;font-family:Segoe UI,Calibri,Arial,sans-serif;text-transform:uppercase;"><b>Assessment Name :</b> AS2 </label>
			  <label style="display:block;font-weight:600;letter-spacing:2px;font-size:14px;padding:2px 10px;color:#000;font-family:Segoe UI,Calibri,Arial,sans-serif;text-transform:uppercase;"><b>Term Name :</b> TERM1 </label>
              </b>
			</td>
			  
			  
          </tr>
        </table></td>
    </tr>
  </table>
  <table width="100%" style="background:#fff;border-left:2px solid #000;border-right:2px solid #000;color:#000;border-collapse:collapse;">
    <tr>
      <td width="26%" style="padding: 1%;border: none;text-align: left;font-weight:600;color:#000;"><img src="'.base_url().'assets/images/school.jpg" alt="Site logo" style="vertical-align:middle;max-width:100%;height:auto;width:70px;"/><br>School Logo</td>
      <td width="48%" style="text-align:center;padding:1%;border:0;font-family:sans-serif;font-size:13.3px;text-transform: capitalize;letter-spacing:.8px;font-weight:600;color:#000000;line-height:21px;"> </td>
      <td width="26%" style="text-align:right;padding:1%;border:0;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:600;color:#000000;line-height:21px;"><b style="text-align:right;padding:1%;border:0;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:600;color:#000000;line-height:21px;">Email:</b> demoschool@gmail.com</br>
        <b style="text-align:right;padding:1%;border:0;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:600;color:#000000;line-height:21px;">Phone:</b>  9601552211
        <br>
         <b style="text-align:right;padding:1%;border:0;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:600;color:#000000;line-height:21px;">Mobile:</b>  1234567890<br>
          <b style="text-align:right;padding:1%;border:0;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:600;color:#000000;line-height:21px;">Website:</b>  website.com
 </td>
    </tr>
  </table>
   
 
  <table width="100%" style="background:#fff;border-left:0;border-right:0;color:#000;border-collapse:collapse;">
     <thead>
      <tr>
        <th width="33%" style="border-right: 2px solid #000;border-left: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;background: #578ebe;"> <b style="font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:600;color:#fff;line-height:15px;">Subject</b> </th>
        <th width="33%" style="background: #578ebe;border-right: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;"> <b style="font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:600;color:#fff;line-height:15px;">Max.Mark</b> </th>
        <th width="33%" style="background: #578ebe;border-right: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;"> <b style="font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:600;color:#fff;line-height:15px;">Mark</b> </th>       
     </tr>
    </thead>
    <tbody>
      <tr>
        <td width="33%" style="border-bottom: 2px solid #000;border-left: 2px solid #000;border-right: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:500;color:#000000;line-height:15px;">Biology</td>
        <td width="33%" style="border-bottom: 2px solid #000;background-color: #fff;text-transform: uppercase;border-right: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:500;color:#000000;line-height:15px;"> 100 
		</td>
        <td width="33%" style="border-bottom: 2px solid #000;border-right: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:500;color:#000000;line-height:15px;">90</td>             
      </tr>
	   <tr>
        <td width="33%" style="border-bottom: 2px solid #000;border-left: 2px solid #000;border-right: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:500;color:#000000;line-height:15px;">Social Science</td>
        <td width="33%" style="border-bottom: 2px solid #000;background-color: #fff;text-transform: uppercase;border-right: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:500;color:#000000;line-height:15px;"> 100 
		</td>
        <td width="33%" style="border-bottom: 2px solid #000;border-right: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:500;color:#000000;line-height:15px;">90</td>             
      </tr>
	   <tr>
        <td width="33%" style="border-bottom: 2px solid #000;border-left: 2px solid #000;border-right: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:500;color:#000000;line-height:15px;">Hindi</td>
        <td width="33%" style="border-bottom: 2px solid #000;background-color: #fff;text-transform: uppercase;border-right: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:500;color:#000000;line-height:15px;"> 100 
		</td>
        <td width="33%" style="border-bottom: 2px solid #000;border-right: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:500;color:#000000;line-height:15px;">90</td>             
      </tr>
	   <tr>
        <td width="33%" style="border-bottom: 2px solid #000;border-left: 2px solid #000;border-right: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:500;color:#000000;line-height:15px;">History</td>
        <td width="33%" style="border-bottom: 2px solid #000;background-color: #fff;text-transform: uppercase;border-right: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:500;color:#000000;line-height:15px;"> 100 
		</td>
        <td width="33%" style="border-bottom: 2px solid #000;border-right: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:500;color:#000000;line-height:15px;">90</td>             
      </tr>
    </tbody>
	<thead>
      <tr>
        <th width="33%" style="border-right: 2px solid #000;border-left: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;background: #578ebe;"> <b style="font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:600;color:#fff;line-height:15px;">Total</b> </th>
        <th width="33%" style="background: #578ebe;border-right: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;"> <b style="font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:600;color:#fff;line-height:15px;">400</b> </th>
        <th width="33%" style="background: #578ebe;border-right: 2px solid #000;padding:1%;border-top:2px solid #000;border-collapse:collapse;"> <b style="font-family:sans-serif;font-size:12px;letter-spacing:.8px;font-weight:600;color:#fff;line-height:15px;">360</b> </th>       
     </tr>
    </thead>
  </table>
</div>';	
							
													  								  
//echo $html; die;
@unlink($this->config->item("root_path").'assets/downloadpdf/report_card/student_mark_details.pdf');
$mpdf=new mPDF('utf-8','A4',0,'',10,10,10,24);

$headerpdf='';
$footerpdf='';
  
$mpdf->SetHTMLHeader($headerpdf);
$mpdf->SetHTMLFooter($footerpdf);
$mpdf->AddPage();
$mpdf->WriteHTML($html);
$mpdf->Output($this->config->item("root_path").'assets/downloadpdf/report_card/student_mark_details.pdf','F');  
